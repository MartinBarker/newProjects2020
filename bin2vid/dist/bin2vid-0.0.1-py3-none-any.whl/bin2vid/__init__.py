import os
import sys

print("~~~~ bin2vid ~~~~")

#import requests
#import json
#import mutagen
#from mutagen.easyid3 import EasyID3
#from mutagen.id3 import ID3, APIC, ID3NoHeaderError
#from mutagen.mp3 import MP3 
#import re
